### React JS CRUD Project with API Call
#### https://youtu.be/5PfvoAj-SMk

### To run this Project follow below steps
```bash
npm install 
npm install -g json-server
```
#### Open Terminal 1 - Start Json server
```bash
json-server --watch db.json --port 3333
```
#### Open Terminal 2 - Run React JS Application
```bash
npm start
```
